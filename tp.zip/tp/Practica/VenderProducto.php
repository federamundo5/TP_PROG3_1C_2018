<?php
/*recibe por get el nombre del producto y la cantidad, hace llamadas a metodos
 y retorna el precio total a pagar
*/

include_once 'producto.php'; 

$nombre = $_GET['nombre'];
$cantidad = $_GET['cantidad'];

$producto = new Producto($nombre,5);

$array =  $producto->retornarArray();
foreach($array as $product)
{
echo $product->ToString();
echo$product->precioMasIva(1);
}
?>