<?php

/*
Recibe nombre, mail, clave y sexo de un cliente, busca por mail y si existen los datos se guardan
los nuevos datos ingresados y la foto se guarda con el nuevo nombre
*/
include_once 'producto.php'; 

//$apellido = isset($_POST['apellido']) ? $_POST['apellido'] : NULL;
$nombre = "Merca";


$product = Producto::BorrarProducto($nombre);



?>