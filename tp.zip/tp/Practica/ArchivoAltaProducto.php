<?php

/*
Recibe por post el nombre, el precio y tambien una foto del producto guardar la foto con el nombre del producto 

*/
include_once 'producto.php'; 

$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$info = pathinfo($_FILES['foto']['tmp_name']);

$imagenNombre = $nombre.".png"; 
$target = $imagenNombre;
//$target = "imagenes/".$imagenNombre;
move_uploaded_file( $_FILES['foto']['tmp_name'], $target);
//$estampa = imagecreatefrompng('fotoDos.png');
//$margen_dcho = 10;
//$margen_inf = 10;
//$sx = imagesx($estampa);
//$sy = imagesy($estampa);


$producto = new Producto($nombre,$precio);
$producto->Guardar($producto);
?>