<?php
/*
Posee 2 atributos privados implementa la interfaz IVendible con el metodo precio + IVA y tiene un metodo que se
 llama retornar array de productos
que retorna un array con 5 productos 
*/
include_once 'interfaces/IVendible.php'; 

class Producto implements IVendible {
private $nombre;
private $precio;

public    function __construct($nombre,$precio) {
    $this->nombre = $nombre;
    $this->precio = $precio;
}




public function retornarArray(){
$p1 = new Producto("Sandwich", 33);
$p2 = new Producto("Chicle", 2);
$p3 = new Producto("Coca", 6);
$p4 = new Producto("Chocolate",25);
$p5 = new Producto("Cigarrillo", 50);

$array = array($p1,$p2,$p3,$p4,$p5);
return $array;

}

public function ToString()
{
      return $this->nombre." - ".$this->precio."\r\n";
}


public function precioMasIva($cantidad){

    $precioTotal= 0;
    for ($i=0; $i < $cantidad ; $i++) { 
    $precioTotal = $precioTotal + $this->precio +($this->precio * 0.21);
    }
   return $precioTotal;
}


public static function Guardar($obj)
{
    $resultado = FALSE;
    
    //ABRO EL ARCHIVO
    $ar = fopen("archivos/productos.txt", "a");
    
    //ESCRIBO EN EL ARCHIVO
    $cant = fwrite($ar, $obj->ToString());
    
    if($cant > 0)
    {
        $resultado = TRUE;			
    }
    //CIERRO EL ARCHIVO
    fclose($ar);
    
    return $resultado;
}

public static function TraerTodosLosProductos()
{
    $ListaDeProductosLeidos = array();

    //leo todos los productos del archivo
    $archivo=fopen("archivos/productos.txt", "r");
    
    while(!feof($archivo))
    {
        $archAux = fgets($archivo);
        $productos = explode(" - ", $archAux);
        //http://www.w3schools.com/php/func_string_explode.asp
        $productos[0] = trim($productos[0]);
        if($productos[0] != ""){
            $ListaDeProductosLeidos[] = new Producto($productos[0], $productos[1]);
        }
    }
    fclose($archivo);
    
    return $ListaDeProductosLeidos;
  
}


public static function TraerUnProducto($nombre)
{
    $producto = array();

    //leo todos los productos del archivo
    $archivo=fopen("archivos/productos.txt", "r");
    
    while(!feof($archivo))
    {
        $archAux = fgets($archivo);
        $productos = explode(" - ", $archAux);
        //http://www.w3schools.com/php/func_string_explode.asp
        $productos[0] = trim($productos[0]);
        if($productos[0] != "" && $productos[0] == $nombre){
            $producto = new Producto($productos[0], $productos[1]);
        }
        
    }
    fclose($archivo);
       
    if (empty($producto)) {
        echo "Vacio";
    }
    return $producto;


}


public static function CrearTabla()
{
    $lista =Producto::TraerTodosLosProductos();

    $TablaCompleta=" <table border=1><th> Producto </th><th> Precio</th><th> Foto</th>";
    $renglon="";
    
    foreach ($lista as $producto) 
    {
        $renglon= $renglon."<tr> <td> ".$producto->nombre ."</td> <td> ". $producto->precio."</td> <td> <img src='$producto->nombre.png'></td>  </tr>"; 
        
    }
    $TablaCompleta =$TablaCompleta.$renglon." </table>";

    $archivo=fopen("archivos/tablaFacturacion.php", "w");
    fwrite($archivo, $TablaCompleta);
}

public static function BorrarProducto($nombre)
{
  
    $ListaDeProductosLeidos = array();
    
        //leo todos los productos del archivo
        $archivo=fopen("archivos/productos.txt", "r");
        
        while(!feof($archivo))
        {
            $archAux = fgets($archivo);
            $productos = explode(" - ", $archAux);
            //http://www.w3schools.com/php/func_string_explode.asp
            $productos[0] = trim($productos[0]);
            if($productos[0] != "" && $productos[0] != $nombre){
                $ListaDeProductosLeidos[] = new Producto($productos[0], $productos[1]);
            }
        }
        fclose($archivo);
        unlink("archivos/productos.txt");


        foreach($ListaDeProductosLeidos as $product)
        {
        $product->Guardar($product);
        }
  
}
}
?>