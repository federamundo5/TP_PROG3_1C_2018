<?php
include_once 'Cliente.php'; 

$apellido = isset($_POST['apellido']) ? $_POST['apellido'] : NULL;
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
$sexo = isset($_POST['sexo']) ? $_POST['sexo'] : NULL;
$mail = isset($_POST['mail']) ? $_POST['mail'] : NULL;

$cliente = new Cliente($nombre,$apellido,$sexo,$mail);
$cliente->validarCliente($nombre,$apellido,$sexo,$mail);
//Cliente::Guardar($cliente);
?>