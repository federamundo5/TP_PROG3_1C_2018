<?php

/*
Recibe nombre, mail, clave y sexo de un cliente, busca por mail y si existen los datos se guardan
los nuevos datos ingresados y la foto se guarda con el nuevo nombre
*/
include_once 'producto.php'; 

//$apellido = isset($_POST['apellido']) ? $_POST['apellido'] : NULL;
//$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;
//$nombre = isset($_POST['precio']) ? $_POST['precio'] : NULL;
//$sexo = isset($_POST['sexo']) ? $_POST['sexo'] : NULL;

/*$chicle = "Chicle";
$product = Producto::TraerUnProducto($chicle);
Producto::BorrarProducto($chicle);
$producto = new Producto($chicle,25);
Producto::Guardar($producto);*/

$name = "Chicle";
$nameNuevo = "Dot";
if (file_exists($name.'.png')) {
    rename($name.'.png',$nameNuevo.'.png');
} else {
    echo "The file  does not exist";
}
?>