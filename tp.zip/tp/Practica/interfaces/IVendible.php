<?php

interface IVendible{

    public function precioMasIva($cantidad);
}
?>