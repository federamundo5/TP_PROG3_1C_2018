<?php

Class Cliente
{

public $nombre;
public $apellido;
public  $sexo;
public  $mail;


public    function __construct($nombre,$apellido, $sexo, $mail) {
       $this->nombre = $nombre;
       $this->apellido = $apellido;
       $this->sexo = $sexo;
       $this->mail = $mail;       
   }


   public  function ValidarCliente($nombre,$apellido,$sexo,$mail)
   {
    if (!preg_match("/^[a-zA-Z ]*$/",$nombre) || (!preg_match("/^[a-zA-Z ]*$/",$apellido) || !filter_var($mail, FILTER_VALIDATE_EMAIL))) {
        echo("Fallo validacion");       
        return false;
   }
   echo("Todo bien");
   return true;
}

   public function ToString()
   {
         return $this->nombre." - ".$this->apellido." - ".$this->sexo." - ".$this->mail."\r\n";
   }


   public static function Guardar($obj)
   {
       $resultado = FALSE;
       
       //ABRO EL ARCHIVO
       $ar = fopen("archivos/ClientesActuales.txt", "a");
       
       //ESCRIBO EN EL ARCHIVO
       $cant = fwrite($ar, $obj->ToString());
       
       if($cant > 0)
       {
           $resultado = TRUE;			
       }
       //CIERRO EL ARCHIVO
       fclose($ar);
       
       return $resultado;
   }

}
?>