<?php

/*
Retorna una tabla de productos con la imagen correspondiente de cada productos
*/
include_once 'producto.php'; 



//var_dump($array);

Producto::CrearTabla();


include("archivos/tablaFacturacion.php");

?>