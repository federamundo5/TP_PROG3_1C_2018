 <table border=1><th> Producto </th><th> Precio</th><th> Foto</th><tr> <td> Celular</td> <td> 15000
</td> <td> <img src='Celular.png'></td>  </tr><tr> <td> Coca</td> <td> 25
</td> <td> <img src='Coca.png'></td>  </tr><tr> <td> Chicle</td> <td> 25
</td> <td> <img src='Chicle.png'></td>  </tr> </table>